# ### 6. Deployment with Streamlit:
# * In this task, you will deploy your logistic regression model using Streamlit. The deployment can be done locally or online via Streamlit Share. Your task includes creating a Streamlit app in Python that involves loading your trained model and setting up user inputs for predictions. 

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, RocCurveDisplay
import streamlit as st

# Load the dataset
df = pd.read_csv('diabetes.csv')
# Preprocess the data (handle missing values, encode categorical variables, etc.)
X = df.drop('Outcome', axis=1)
y = df['Outcome']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LogisticRegression()
model.fit(X_train, y_train)
# Evaluate the model
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_pred)
# Streamlit app
st.title("Diabetes Prediction using Logistic Regression")
# input fields are in 2 columns for better ui
st.write("Enter the following details to predict whether a person has diabetes or not:")
col1, col2 = st.columns(2)
with col1:
    pregnancies = st.number_input("Pregnancies", min_value=0, value=15)
    st.write("Normal range for Pregnancies: 0-17")
    glucose = st.number_input("Glucose", min_value=0, value=100)
    st.write("Normal range for Glucose: 70-130 mg/dL")
    bmi = round(st.number_input("BMI", min_value=0.0, value=22.0), 2)
    st.write("Normal range for BMI: 18.5-24.9")
    diabetes_pedigree = round(st.number_input("Diabetes Pedigree", min_value=0.0, value=0.5), 2)
    st.write("Normal range for Diabetes Pedigree: 0.0-2.42")
with col2:
    blood_pressure = st.number_input("Blood Pressure", min_value=0, value=70)
    st.write("Normal range for Blood Pressure: 80-120 mm Hg")
    skin_thickness = st.number_input("Skin Thickness", min_value=0, value=20)
    st.write("Normal range for Skin Thickness: 0-99 mm")
    insulin = st.number_input("Insulin", min_value=0, value=30)
    st.write("Normal range for Insulin: 2-200 µU/mL")
    age = st.number_input("Age", min_value=0, value=30)
    st.write("Normal range for Age: 0-120 years")
if st.button("Predict"):
    input_data = [[pregnancies, glucose, blood_pressure, skin_thickness, insulin, bmi, diabetes_pedigree, age]]
    prediction = model.predict(input_data)
    # input data to dataframe and the prediction in the csv file so the model can be retrained later
    new_data = pd.DataFrame(input_data, columns=X.columns)
    new_data['Outcome'] = prediction
    df = pd.concat([df, new_data], ignore_index=True)
    df.to_csv('diabetes.csv', index=False)
    if prediction[0] == 1:
        st.write("The model predicts that the person has diabetes.")
    else:
        st.write("The model predicts that the person does not have diabetes.")
